<?php
    use App\Models\ServiceCategory;

    // Fetch categories and their related products directly
    $serviceCategories = ServiceCategory::with('sproducts')->get();
?>
<header class="ltn__header-area ltn__header-3">
    <div class="ltn__header-top-area border-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <div class="ltn__top-bar-menu">
                        <?php if($contactInfo): ?>
                    
                       
                        <ul>
                            <li><a class="text-white" href="mailto:<?php echo e($contactInfo->email); ?>"><i
                                        class="icon-mail"></i> <?php echo e($contactInfo->email); ?></a></li>
                            <li><a class="text-white" href="#"><i class="icon-placeholder"></i> <?php echo e($contactInfo->address); ?></a></li>
                        </ul>
                        <?php else: ?>
                        <p>No contact information found. </p>
                    <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-5">
                    <div class="top-bar-right text-right text-end">
                        <div class="ltn__top-bar-menu">
                            <ul>

                                <li>
                                    <!-- ltn__social-media -->
                                    <div class="ltn__social-media">
                                        <ul>
                                            <li><a class="text-white" href="#" title="Facebook"><i
                                                        class="fab fa-facebook-f"></i></a></li>
                                            <!-- <li><a class="text-white" href="#" title="Twitter"><i
                                                        class="fab fa-twitter"></i></a>
                                            </li> -->

                                            <li><a class="text-white" href="#" title="Instagram"><i
                                                        class="fab fa-instagram"></i></a></li>
                                            <li><a class="text-white" href="#" title="Viber"><i
                                                        class="fab fa-viber"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ltn__header-top-area end -->
    <!-- ltn__header-middle-area start -->
    <div class="ltn__header-middle-area">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="site-logo">
                        <?php if($contactInfo): ?>
                        <?php if($contactInfo->logo): ?>
                        <a href="/">

                            <img src="<?php echo e(asset('storage/' . $contactInfo->logo)); ?>" alt="logo" height="80px" style="object-fit: contain;">
                        </a>
                    <?php else: ?>
                        No Logo
                    <?php endif; ?>
                    <?php endif; ?>
                       
                    </div>
                </div>
                <div class="col header-contact-serarch-column d-none d-lg-block">
                    <div class="header-contact-search">

                        <!-- header-search-2 -->
                        <div class="header-search-2">
                            <form id="#123" method="get" action="#">
                                <input type="text" name="search" value="" placeholder="Search here..." />
                                <button type="submit">
                                    <span><i class="icon-search"></i></span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col d-none d-lg-block d-md-block">

                    <div class="ltn__header-options">
                        <ul>


                            <li>

                                <div class="mini-cart-icon mini-cart-icon-2">
                                    <div class="header-feature-item">
                                        <div class="header-feature-icon">
                                            <i class="fa-brands fa-whatsapp fs-1 text-success"></i>
                                        </div>
                                        <div class="header-feature-info">
                                            <?php if($contactInfo): ?>
                                            <h6>Phone</h6>
                                            <p><a href="tel:<?php echo e($contactInfo->phone); ?>">+977-<?php echo e($contactInfo->phone); ?></a></p>
                                            <?php else: ?>
                                            <p>No contact information found. </p>
                                        <?php endif; ?>
                                            
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ltn__header-middle-area end -->
    <!-- header-bottom-area start -->
    <div
        class="header-bottom-area ltn__border-top ltn__header-sticky  ltn__sticky-bg-white--- ltn__sticky-bg-secondary ltn__secondary-bg section-bg-1 menu-color-white d-none d-lg-block">
        <div class="container">
            <div class="row">
                <div class="col header-menu-column justify-content-center">
                    <div class="sticky-logo">
                        <div class="site-logo">
                            <?php if($contactInfo): ?>
                            <?php if($contactInfo->logo): ?>
                            <img src="<?php echo e(asset('storage/' . $contactInfo->logo)); ?>" alt="Logo" height="80px" style="object-fit: contain;">
                        <?php else: ?>
                            No Logo
                        <?php endif; ?>
                        <?php endif; ?>
                        </div>
                    </div>
                    <div class="header-menu header-menu-2">
                        <nav>
                            <div class="ltn__main-menu">
                                <ul>
                                    <li><a href="/">Home</a>

                                    </li>
                                    <li><a href="<?php echo e(route('about')); ?>">About</a>

                                    </li>
                                    <li><a href="<?php echo e(route('shop')); ?>">Shop</a>

                                    </li> 
                                    <li class="menu-icon"><a href="#">Services</a>
                                        <ul>
                                            <?php $__currentLoopData = $serviceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('services.show', $category->id)); ?>"><?php echo e($category->name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          
                                        </ul>
                                    </li>
                                  

                                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- header-bottom-area end -->
</header>
<!-- HEADER AREA END --><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/users/layout/header.blade.php ENDPATH**/ ?>