<div class="section pt-lg-5 pt-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <?php if($about): ?>
                    <h1 class="section-title"><?php echo e($about->title); ?></h1>
                    <div class="clearfix">
                        <img src="<?php echo e(asset('storage/' . $about->image)); ?> " class="col-md-6 float-md-end mb-3 ms-md-3"
                            alt="...">


                        <p> <?php echo $about->description; ?></p>
                    <?php else: ?>
                        <p>No data available.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/users/layout/about-us.blade.php ENDPATH**/ ?>