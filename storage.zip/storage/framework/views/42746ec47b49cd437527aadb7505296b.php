<!doctype html>
<html lang="en">

<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body data-topbar="dark">

    <div id="layout-wrapper">

        <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">

                    <?php echo $__env->yieldContent('content'); ?>
                </div>

            </div>

            <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>
    

    <div class="rightbar-overlay"></div>

    <script src="<?php echo e(asset('admin-dashboard/assets/libs/jquery/jquery.min.js')); ?> "></script>
    <script src="<?php echo e(asset('admin-dashboard/assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?> "></script>
    <script src="<?php echo e(asset('admin-dashboard/assets/libs/metismenu/metisMenu.min.js')); ?> "></script>
    <script src="<?php echo e(asset('admin-dashboard/assets/libs/simplebar/simplebar.min.js')); ?> "></script>
    <script src="<?php echo e(asset('admin-dashboard/assets/libs/node-waves/waves.min.js')); ?> "></script>


    <!-- apexcharts -->
    <script src="<?php echo e(asset('admin-dashboard/assets/libs/apexcharts/apexcharts.min.js')); ?> "></script>

    <!-- jquery.vectormap map -->
    <script
        src="<?php echo e(asset('admin-dashboard/assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js')); ?> ">
    </script>
    <script
        src="<?php echo e(asset('admin-dashboard/assets/libs/admin-resources/jquery.vectormap/maps/jquery-jvectormap-us-merc-en.js')); ?> ">
    </script>

    <!-- Required datatable js -->
    <script src="<?php echo e(asset('admin-dashboard/assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?> "></script>
    <script src="<?php echo e(asset('admin-dashboard/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?> "></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('admin-dashboard/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?> ">
    </script>
    <script
        src="<?php echo e(asset('admin-dashboard/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?> ">
    </script>

    <script src="<?php echo e(asset('admin-dashboard/assets/js/pages/dashboard.init.js')); ?> "></script>

    <!-- App js -->
    <script src="<?php echo e(asset('admin-dashboard/assets/js/app.js')); ?> "></script>
    <?php echo $__env->yieldContent('script'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#editor'))
            .catch(error => {
                console.error(error);
            });
    </script>
    



</body>

</html>
<?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/admin/admin-dashboard.blade.php ENDPATH**/ ?>