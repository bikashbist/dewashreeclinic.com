

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Advertisements</h1>
    <a href="<?php echo e(route('advertisements.create')); ?>" class="btn btn-primary mb-3">Add New Advertisement</a>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Image Name</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $advertisements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($advertisement->id); ?></td>
                <td><?php echo e($advertisement->image_name); ?></td>
                <td><img src="<?php echo e(asset('storage/' . $advertisement->image)); ?>" alt="<?php echo e($advertisement->image_name); ?>" width="100"></td>
                <td>
                    <a href="<?php echo e(route('advertisements.edit', $advertisement->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('advertisements.destroy', $advertisement->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/admin/pages/advertisements/index.blade.php ENDPATH**/ ?>