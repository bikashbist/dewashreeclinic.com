


<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $category->sproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="section pt-lg-5 pt-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="section-title"><?php echo e($product->title); ?></h1>
                <div class="clearfix">

                    <p>
                        <?php echo $product->description; ?>

                    </p>
                  
                    

                 
                </div>
            </div>
        </div>
    </div>


</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('users.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/users/services.blade.php ENDPATH**/ ?>