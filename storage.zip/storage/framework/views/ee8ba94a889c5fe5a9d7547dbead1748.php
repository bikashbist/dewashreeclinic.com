

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0"> Menu Category</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                    <li class="breadcrumb-item active">Create Menu Category</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row mb-3">
                    <label for="menu-category" class="col-sm-2 col-form-label">Menu Category</label>
                    <div class="col-sm-10">
                        <input class="form-control" type="text" placeholder="Menu Name" id="menu-category">
                        <div class="mt-3">

                            <button type="button" class="btn btn-success waves-effect waves-light">Submit</button>
                        </div>
                    </div>
                  
                </div>
            </div>
        </div>
    </div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/admin/pages/menu/create.blade.php ENDPATH**/ ?>