

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('users.layout.about-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/users/pages/about.blade.php ENDPATH**/ ?>