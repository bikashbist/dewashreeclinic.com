<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!-- User details -->
        <div class="user-profile text-center mt-3">
            <div class="">
                
                <img src="<?php echo e(asset('admin-dashboard/assets/images/logo.png')); ?>" alt="" >
            </div>
            <div class="mt-3">
                
                <span class="text-muted"><i class="ri-record-circle-line align-middle font-size-14 text-success"></i> Online</span>
            </div>
        </div>

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Pages</li>

                <li>
                    <a href="/admin-part" class="waves-effect">
                        <i class="ri-dashboard-line"></i><span class="badge rounded-pill bg-success float-end">3</span>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('menu-categories.index')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span>Menu Category</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('menu-products.index')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span>Menu Products</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('about-us.index')); ?>" class="waves-effect">
                        <i class="ri-information-line"></i>
                        <span>About Us</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('gallery.index')); ?>" class="waves-effect">
                        <i class="ri-gallery-line"></i>
                        <span>Gallery</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('contact-info.index')); ?>" class="waves-effect">
                        <i class="ri-gallery-line"></i>
                        <span>Contact Info</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('service-categories.index')); ?>" class="waves-effect">
                        <i class="ri-gallery-line"></i>
                        <span>Service Categories</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('service-products.index')); ?>" class="waves-effect">
                        <i class="ri-gallery-line"></i>
                        <span>Service Products</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('messages.index')); ?>" class="waves-effect">
                        <i class="ri-gallery-line"></i>
                        <span>Messages</span>
                    </a>
                </li>
               


                

            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div><?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>