

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Image</h1>
    <form action="<?php echo e(route('gallery.update', $gallery->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="image_name">Image Name</label>
            <input type="text" name="image_name" id="image_name" class="form-control" value="<?php echo e($gallery->image_name); ?>" required>
        </div>
        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" name="image" id="image" class="form-control">
            <img src="<?php echo e(asset('storage/' . $gallery->image_path)); ?>" alt="<?php echo e($gallery->image_name); ?>" width="100" class="mt-2">
        </div>
        <button type="submit" class="btn btn-primary">Update Image</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/admin/pages/gallery/edit.blade.php ENDPATH**/ ?>