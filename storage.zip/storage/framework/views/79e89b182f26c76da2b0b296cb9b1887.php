

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <h4>Edit About Us</h4>
        <form action="<?php echo e(route('about-us.update', $aboutUs->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo e($aboutUs->title); ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="editor" name="description" rows="5" ><?php echo e($aboutUs->description); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Image</label>
                <input type="file" class="form-control" id="image" name="image">
                <?php if($aboutUs->image): ?>
                    <img src="<?php echo e(asset('storage/' . $aboutUs->image)); ?>" alt="About Us Image" width="100" class="mt-2">
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-success">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/admin/pages/about-us/edit.blade.php ENDPATH**/ ?>