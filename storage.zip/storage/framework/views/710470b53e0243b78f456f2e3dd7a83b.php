

<?php $__env->startSection('content'); ?>
    <!-- SLIDER AREA START (slider-3) -->
    <div class="ltn__slider-area ltn__slider-3---  section-bg-1--- ">
        <div class="container-fluid-x">

            <div class="ltn__slide-active-2 slick-slide-arrow-1 slick-slide-dots-1">
                <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- ltn__slide-item -->
                    <div class="ltn__slide-item ltn__slide-item-10 section-bg-1 bg-image"
                        data-bs-bg="<?php echo e(asset('storage/' . $banner->image)); ?>">
                        <div class="ltn__slide-item-inner">

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>

        </div>
    </div>
    <!-- SLIDER AREA END -->
    <?php echo $__env->make('users.layout.about-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>

    <!-- FEATURE AREA START (Feature - 3) -->
    <div class="ltn__feature-area mt-35 mt--65---">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php if($adv->first()): ?>
                        <img src="<?php echo e(asset('storage/' . $adv->first()->image)); ?>" alt="<?php echo e($adv->first()->image_name); ?>"
                            width="100%">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- FEATURE AREA END -->

    <!-- PRODUCT TAB AREA START (product-item-3) -->
    <div class="ltn__product-tab-area ltn__product-gutter pt-50 pb-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2--- text-center">
                        <h1 class="section-title">Our Products</h1>
                        <p>A highly efficient slip-ring scanner for today's diagnostic requirements.</p>
                    </div>
                    <!-- Dynamic Tab Menu -->
                    <div class="ltn__tab-menu ltn__tab-menu-2 ltn__tab-menu-top-right-- text-uppercase text-center">
                        <div class="nav">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="<?php if($loop->first): ?> active show <?php endif; ?>" data-bs-toggle="tab"
                                    href="#liton_tab_<?php echo e($category->id); ?>">
                                    <?php echo e($category->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!-- Dynamic Tab Content -->
                    <div class="tab-content">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade <?php if($loop->first): ?> active show <?php endif; ?>"
                                id="liton_tab_<?php echo e($category->id); ?>">
                                <div class="ltn__product-tab-content-inner">
                                    <div class="row ltn__tab-product-slider-one-active slick-arrow-1">
                                        <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <!-- ltn__product-item -->
                                            <div class="col-lg-12">
                                                <div class="ltn__product-item ltn__product-item-3 text-center">
                                                    <div class="product-img">
                                                        <a href="#"><img
                                                                src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                                                alt="<?php echo e($product->name); ?>"></a>
                                                        <div class="product-badge">
                                                            <ul>
                                                                <li class="sale-badge">RS: <?php echo e($product->price); ?></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="product-info">
                                                        <div class="product-ratting">
                                                            <ul>
                                                                <li><a href="#"><i class="fas fa-star"></i></a></li>
                                                                <li><a href="#"><i class="fas fa-star"></i></a></li>
                                                                <li><a href="#"><i class="fas fa-star"></i></a></li>
                                                                <li><a href="#"><i
                                                                            class="fas fa-star-half-alt"></i></a></li>
                                                                <li><a href="#"><i class="far fa-star"></i></a></li>
                                                            </ul>
                                                        </div>
                                                        <h2 class="product-title"><a
                                                                href="#"><?php echo e($product->name); ?></a></h2>

                                                    </div>
                                                </div>
                                            </div>
                                            <!-- ltn__product-item End -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- PRODUCT TAB AREA END -->

    <!-- COUNTDOWN AREA START -->
    <div class="ltn__call-to-action-area section-bg-1 bg-image">
        <?php if($adv->last()): ?>
            <img src="<?php echo e(asset('storage/' . $adv->last()->image)); ?>" alt="<?php echo e($adv->last()->image_name); ?>" width="100%">
        <?php endif; ?>
    </div>
    <!-- COUNTDOWN AREA END -->

    </div>
    <!-- COUNTDOWN AREA END -->
<!-- PRODUCT AREA START (Best Selling Item) -->
<div class="ltn__product-area ltn__product-gutter pt-50 pb-50">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title-area ltn__section-title-2 text-center">
                    <h1 class="section-title">Best Selling Item</h1>
                </div>
            </div>
        </div>
        <div class="row ltn__tab-product-slider-one-active--- slick-arrow-1">
            <!-- Loop through category with ID 10 -->
            <?php $__currentLoopData = $featuredproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->id == 10 && $category->products->isNotEmpty()): ?> <!-- Check for category ID 10 -->
                    <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                        <div class="ltn__product-item ltn__product-item-3 text-center">
                            <div class="product-img">
                                <a href="product-details.html">
                                    <img src="<?php echo e(asset('storage/' . $category->products->first()->image)); ?>" 
                                         alt="<?php echo e($category->products->first()->name); ?>">
                                </a>
                                <div class="product-badge">
                                    <ul>
                                        <li class="sale-badge">New</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product-info">
                                <div class="product-ratting">
                                    <ul>
                                        <li><a href="#"><i class="fas fa-star"></i></a></li>
                                        <li><a href="#"><i class="fas fa-star"></i></a></li>
                                        <li><a href="#"><i class="fas fa-star"></i></a></li>
                                        <li><a href="#"><i class="fas fa-star-half-alt"></i></a></li>
                                        <li><a href="#"><i class="far fa-star"></i></a></li>
                                    </ul>
                                </div>
                                <h2 class="product-title">
                                    <a href="product-details.html"><?php echo e($category->products->first()->name); ?></a>
                                </h2>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- PRODUCT AREA END -->

<!-- SMALL PRODUCT LIST AREA START (Featured Products) -->
<div class="ltn__small-product-list-area section-bg-1 pt-50 pb-60">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title-area ltn__section-title-2 text-center">
                    <h1 class="section-title">Featured Products</h1>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- Loop through category with ID 11 -->
            <?php $__currentLoopData = $featuredproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->id == 11 && $category->products->isNotEmpty()): ?> <!-- Check for category ID 11 -->
                    <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Small Product Item -->
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="ltn__small-product-item">
                                <div class="small-product-item-img">
                                    <a href="product-details.html">
                                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
                                    </a>
                                </div>
                                <div class="small-product-item-info">
                                    <div class="product-ratting">
                                        <ul>
                                            <li><a href="#"><i class="fas fa-star"></i></a></li>
                                            <li><a href="#"><i class="fas fa-star"></i></a></li>
                                            <li><a href="#"><i class="fas fa-star"></i></a></li>
                                            <li><a href="#"><i class="fas fa-star-half-alt"></i></a></li>
                                            <li><a href="#"><i class="far fa-star"></i></a></li>
                                        </ul>
                                    </div>
                                    <h2 class="product-title">
                                        <a href="product-details.html"><?php echo e($product->name); ?></a>
                                    </h2>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- SMALL PRODUCT LIST AREA END -->


<div class="section-title-area ltn__section-title-2  pt-lg-5 pt-3">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <h1 class="section-title">We value your feedback</h1>
             
                <form action="<?php echo e(route('messages.store')); ?>" method="POST" class="row g-3">
                    <?php echo csrf_field(); ?> <!-- Include CSRF token for security -->
                    <div class="col-md-6">
                        <label for="inputEmail4" class="form-label ">Email</label>
                        <input type="email" name="email" class="form-control" id="inputEmail4" required>
                    </div>
                    <div class="col-md-6">
                        <label for="phoneNumber" class="form-label ">Phone</label>
                        <input type="number" name="phone" class="form-control" id="phoneNumber" required>
                    </div>
                    <div class="col-12">
                        <label for="messager" class="form-label ">Message</label>
                        <textarea name="message" class="form-control" id="messager" rows="3" required></textarea>
                    </div>
                    <div class="col-12 ">
                        <button type="submit" class="btn btn-primary mb-5">Send Message</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


</div>

 

    <!-- TESTIMONIAL AREA START (testimonial-4) -->
    
    <!-- TESTIMONIAL AREA END -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/users/index.blade.php ENDPATH**/ ?>