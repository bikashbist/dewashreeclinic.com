

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Contact Info List</h2>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($contactInfo): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Logo</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($contactInfo->id); ?></td>
                    <td><?php echo e($contactInfo->phone); ?></td>
                    <td><?php echo e($contactInfo->email); ?></td>
                    <td><?php echo e($contactInfo->address); ?></td>
                    <td>
                        <?php if($contactInfo->logo): ?>
                            <img src="<?php echo e(asset('storage/' . $contactInfo->logo)); ?>" alt="Logo" width="100">
                        <?php else: ?>
                            No Logo
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('contact-info.edit', $contactInfo->id)); ?>" class="btn btn-warning">Edit</a>
                        
                        <form action="<?php echo e(route('contact-info.destroy', $contactInfo->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this contact info?')">Delete</button>
                        </form>
                    </td>
                </tr>
            </tbody>
        </table>
    <?php else: ?>
        <p>No contact information found. <a href="<?php echo e(route('contact-info.create')); ?>">Create New</a></p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/admin/pages/contact-info/index.blade.php ENDPATH**/ ?>