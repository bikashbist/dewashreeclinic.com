

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit Contact Info</h2>
    
    <form action="<?php echo e(route('contact-info.update', $contactInfo->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone', $contactInfo->phone)); ?>">
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $contactInfo->email)); ?>">
        </div>

        <div class="form-group">
            <label for="address">Address</label>
            <input type="text" name="address" class="form-control" value="<?php echo e(old('address', $contactInfo->address)); ?>">
        </div>

        <div class="form-group">
            <label for="logo">Logo</label>
            <?php if($contactInfo->logo): ?>
                <div class="mb-2">
                    <img src="<?php echo e(asset('storage/' . $contactInfo->logo)); ?>" alt="Logo" width="100">
                </div>
            <?php endif; ?>
            <input type="file" name="logo" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/admin/pages/contact-info/edit.blade.php ENDPATH**/ ?>