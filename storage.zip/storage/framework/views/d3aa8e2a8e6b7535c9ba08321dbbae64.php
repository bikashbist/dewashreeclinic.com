

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Service Products</h2>
    <a href="<?php echo e(route('service-products.create')); ?>" class="btn btn-success mb-3">Add New Product</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Category</th>
                <th>Title</th>
                <th>Desc</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                
                    <td><?php echo e($product->scategory ? $product->scategory->name : 'No Category'); ?></td>
                    <td><?php echo e($product->title); ?></td>
                    <td><?php echo $product->description; ?></td>
                    <td>
                        <a href="<?php echo e(route('service-products.edit', $product->id)); ?>" class="btn btn-primary">Edit</a>
                        <form action="<?php echo e(route('service-products.destroy', $product->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/admin/pages/service-products/index.blade.php ENDPATH**/ ?>