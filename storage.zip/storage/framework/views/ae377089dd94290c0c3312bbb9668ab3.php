

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card p-4">
            <h4>Create Menu Category</h4>

            <form action="<?php echo e(route('menu-categories.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="menu-category" class="form-label">Menu Category</label>
                    <input type="text" class="form-control" id="menu-category" name="name" placeholder="Menu Name">
                </div>
    
                <div class="mb-3">
                    <label for="image" class="form-label">Image</label>
                    <input type="file" name="image" id="image" class="form-control">
                </div>
    
                <button type="submit" class="btn btn-success">Submit</button>
            </form>
        </div>
   
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/admin/pages/menu-categories/create.blade.php ENDPATH**/ ?>