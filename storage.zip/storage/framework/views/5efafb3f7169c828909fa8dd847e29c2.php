<head>
        
    <meta charset="utf-8" />
    <title>Dashboard </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Bakers Galler" name="description" />
    <meta content="bakers gallery caffe" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('admin-dashboard/assets/images/favicon.ico')); ?> ">

    <!-- jquery.vectormap css -->
    <link href="<?php echo e(asset('admin-dashboard/assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css')); ?> " rel="stylesheet" type="text/css" />

    <!-- DataTables -->
    <link href="<?php echo e(asset('admin-dashboard/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?> " rel="stylesheet" type="text/css" />

    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('admin-dashboard/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?> " rel="stylesheet" type="text/css" />  

    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('admin-dashboard/assets/css/bootstrap.min.css')); ?> " id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('admin-dashboard/assets/css/icons.min.css')); ?> " rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('admin-dashboard/assets/css/app.min.css')); ?> " id="app-style" rel="stylesheet" type="text/css" />

    <style>
        .table {
            background: #ffffff;
        }
    </style>

</head><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/admin/layout/head.blade.php ENDPATH**/ ?>