

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Create Service Category</h2>
    <form action="<?php echo e(route('service-categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Category Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/admin/pages/service-categories/create.blade.php ENDPATH**/ ?>