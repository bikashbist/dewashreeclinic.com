<div class="cart">
    <img src="<?php echo e(asset('bakers/images/logo.png')); ?>" alt="logo" width="100" style="border-radius: 50%;">
</div>
<div class="login ms-3"><a href="#"> <i class="fa-solid fa-house-chimney"></i> Home</a></div>
<div class="login ms-3"><a href="#about"> <i class="fa-solid fa-mug-saucer"></i> About</a></div>
<div class="login ms-3"><a href="#gallery"> <i class="fa-regular fa-image"></i> Gallery</a>
</div>
<div class="login ms-3"><a href="#menu"> <i class="fa-regular fa-floppy-disk"></i> Menu</a>
</div>

<div class="login ms-3"><a href="#ContactUS"> <i class="fa-regular fa-address-card"></i> Contact Us</a>
</div><?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/users/layout/desktop-navbar.blade.php ENDPATH**/ ?>