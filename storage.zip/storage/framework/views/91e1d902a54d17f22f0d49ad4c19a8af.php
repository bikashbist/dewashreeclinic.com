

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Gallery</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <a href="<?php echo e(route('gallery.create')); ?>" class="btn btn-primary">Add New Image</a>
        <table class="table mt-3">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Image Name</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($gallery->image_name); ?></td>
                        <td><img src="<?php echo e(asset('storage/' . $gallery->image_path)); ?>" alt="<?php echo e($gallery->image_name); ?>"
                                width="100"></td>
                        <td>
                            <a href="<?php echo e(route('gallery.edit', $gallery->id)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('gallery.destroy', $gallery->id)); ?>" method="POST"
                                style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/admin/pages/gallery/index.blade.php ENDPATH**/ ?>