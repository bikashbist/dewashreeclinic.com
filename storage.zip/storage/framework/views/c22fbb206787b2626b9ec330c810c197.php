

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <h4>Edit Menu Category</h4>

        <form action="<?php echo e(route('menu-categories.update', $menuCategory->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="menu-category" class="form-label">Menu Category</label>
                <input type="text" class="form-control" id="menu-category" name="name" value="<?php echo e($menuCategory->name); ?>" placeholder="Menu Name">
            </div>

            <div class="mb-3">
                <label for="image" class="form-label">Image</label>
                <input type="file" name="image" id="image" class="form-control">
                <?php if($menuCategory->image): ?>
                    <img src="<?php echo e(asset('storage/' . $menuCategory->image)); ?>" alt="<?php echo e($menuCategory->name); ?>" width="100" class="mt-2">
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-success">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\backend-project\resources\views/admin/pages/menu-categories/edit.blade.php ENDPATH**/ ?>