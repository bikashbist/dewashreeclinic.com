

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Banner</h1>
    <form action="<?php echo e(route('banner.update', $banner->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="image_name">Image Name</label>
            <input type="text" name="image_name" id="image_name" class="form-control" value="<?php echo e($banner->image_name); ?>" required>
        </div>
        <div class="form-group">
            <label for="image">Current Image</label>
            <div>
                <img src="<?php echo e(asset('storage/' . $banner->image)); ?>" alt="<?php echo e($banner->image_name); ?>" style="width: 100px;">
            </div>
            <input type="file" name="image" id="image" class="form-control">
        </div>
        <button type="submit" class="btn btn-success">Update Banner</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/admin/pages/banners/edit.blade.php ENDPATH**/ ?>