

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="mb-sm-0"> Message</h4>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
    
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Message</th>
                    <th>Sent At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($message->email); ?></td>
                        <td><?php echo e($message->phone); ?></td>
                        <td><?php echo e($message->message); ?></td>
                        <td><?php echo e($message->created_at->format('Y-m-d H:i:s')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/admin/pages/messages/index.blade.php ENDPATH**/ ?>