

<?php $__env->startSection('content'); ?>

<h1>this is services page</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/users/pages/services.blade.php ENDPATH**/ ?>