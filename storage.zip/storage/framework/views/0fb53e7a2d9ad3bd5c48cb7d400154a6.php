

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <h4>About Us</h4>
        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
        <?php if($aboutUs): ?>
            <a href="<?php echo e(route('about-us.edit', $aboutUs->id)); ?>" class="btn btn-warning btn-sm">Edit About Us</a>
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td><?php echo e($aboutUs->title); ?></td>
                        <td><?php echo $aboutUs->description; ?></td>
                        <td>
                            <?php if($aboutUs->image): ?>
                                <img src="<?php echo e(asset('storage/' . $aboutUs->image)); ?>" alt="About Us Image" width="100">
                            <?php else: ?>
                                <p>No image available</p>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('about-us.edit', $aboutUs->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('about-us.destroy', $aboutUs->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
            <p>No About Us information found. <a href="<?php echo e(route('about-us.create')); ?>">Create About Us</a></p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\my-project\dewashreeclinic\resources\views/admin/pages/about-us/index.blade.php ENDPATH**/ ?>